import styled from "styled-components";

export const SharedContainer = styled.div`
   min-height: 100vh;
   min-width: 100vw;
`