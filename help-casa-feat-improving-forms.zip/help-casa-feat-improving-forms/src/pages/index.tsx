export default function Home() {
  return (
    <div>
      Pagina Home
    </div>
  );
}
